import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import db from './db/config.js';
import mainRoutes from './mainRoutes.js';
import session from 'express-session';


const app = express();
const port = 3000;

// קבלת הנתיב של הקובץ הנוכחי
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


// Set up session middleware
app.use(session({
  secret: 'your-secret-key',  
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }  
}));




// הגדרת EJS כתצוגה ברירת מחדל
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../../Client/Views'));

// הגדרת תיקיית Client כסטטית
app.use(express.static(path.join(__dirname, '../../Client')));

// ניתוח נתוני טופס POST
app.use(express.urlencoded({ extended: true }));

app.use('/', mainRoutes);



app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
