
import express from 'express';
const router = express.Router();
import * as userService from './userService.js';
import * as clientService from './clientService.js';
import * as passwordValidator from './Security/passwordValidator.js';
import errorMessages from './errorMessages.json' assert { type: 'json' };
import fs from 'fs';

// Load password policy
const passwordPolicy = JSON.parse(fs.readFileSync('./Security/password_policy.json', 'utf8'));
// Middleware to initialize login attempts
function initializeLoginAttempts(req, res, next) {
  if (!req.session.loginAttempts) {
    req.session.loginAttempts = {};  // Initialize an empty object for login attempts tracking
  }
  next();
}

// Add middleware to initialize login attempts
router.use(initializeLoginAttempts);

//GET

// Root route (homepage)
router.get('/', (req, res) => {
  res.render('homepage');  // Ensure you have homepage.ejs in your views folder
});

router.get('/homepage', (req, res) => {
  res.render('homepage');  // Ensure you have homepage.ejs in your views folder
});

// Register page
router.get('/register', (req, res) => {
  res.render('register');
});

// Login page
router.get('/login', (req, res) => {
  res.render('login',{ errorMessage: null }); 
});

// Display client table
router.get('/clients', async (req, res) => {
  const userEmail = req.session.userEmail;  // Get logged-in user's email from session
  if (!userEmail) {
    return res.status(401).send('You need to log in first.');
  }
  try {
    const clients = await clientService.getClients();  // Fetch clients
    res.render('clientTable', { clients });  // Render the client table view
  } catch (error) {
    console.error('Error fetching clients:', error);
    res.status(500).send('Error fetching clients');
  }
});

// Add client page
router.get('/clients/add', (req, res) => {
  res.render('addClient');  // Ensure addClient.ejs exists in your views folder
});


//forgot password page
router.get('/forgotPassword', (req, res) => {
  res.render('forgotPassword');  // Ensure you have forgotPassword.ejs in your views folder
});

// GET route to display the verification token page
router.get('/verify-token', (req, res) => {
  const { email } = req.query;  // Get the email from the query string
  res.render('verifyToken', { email });  // Render a page where the user enters the token
});

router.get('/change-password', (req, res) => {
  const { email } = req.query;  // Get the email from the query string
  console.log(`email recived in change password page: ${email}`);
  if (!email) {
      return res.redirect('/forgotPassword');  // If no email, redirect back to forgot password page
  }
  // Render the change password page, passing the email
  res.render('changePassword', { email });
});
// Display the verify current password page
router.get('/verify-current-password', (req, res) => {
  const userEmail = req.session.userEmail;
  if (!userEmail) {
    return res.status(401).send('You need to log in first.');
  }
  res.render('verifyCurrentPassword', { email: userEmail, errorMessage: null });
});



///POST

// Handle registration POST requests
router.post('/register', async (req, res) => {
  const { username, email, password } = req.body;
  console.log(`mainr username: ${username}`);
  console.log(`mainr email: ${email}`);
  console.log(`mainr password: ${password}`);

  try {
    if (!passwordValidator.validatePasswordLength(password)) {
      return res.status(400).render('register', { errorMessage: errorMessages.improper_password_requirements });
    }

    await userService.registerUser(username, email, password);
    res.redirect('/');
  } catch (error) {
    // Check if the error is due to an existing email
    if (error.message === 'Email already exists') {
      return res.status(400).render('register', { errorMessage: 'Email already exists. Please use a different email.' });
    }
    
    // For other errors, render a generic error message
    res.status(500).render('register', { errorMessage: 'An error occurred during registration. Please try again later.' });
  }
});

// Handle login POST requests
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  console.log(`mr email: ${email}`);
  try {
    if (!req.session.loginAttempts[email]) {
      req.session.loginAttempts[email] = 0;
    }

    // Check if the user has exceeded the login attempts limit
    if (req.session.loginAttempts[email] >= passwordPolicy.password_requirements.login_attempts_limit) {
      return res.status(403).render('login', { errorMessage: 'Too many failed login attempts. Please try again later.' });
    }

    const isAuthenticated = await userService.authenticateUser(email, password);
    if (isAuthenticated) {
      req.session.userEmail = email;  // Save logged-in user's email in session
      req.session.loginAttempts[email] = 0; // Reset login attempts after successful login
      res.redirect('/clients');
    } else {
      req.session.loginAttempts[email] += 1;  // Increment failed login attempts
      console.log(`Failed login attempts for ${email}: ${req.session.loginAttempts[email]}`);
      res.status(401).render('login', { errorMessage: 'Invalid email or password' });
    }
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).render('login', { errorMessage: 'An error occurred. Please try again.' });
  }
});

// handle Add client post requests
router.post('/clients/add', (req, res) => {
  const { name, address, clientEmail, clientPassword } = req.body;
  const userEmail = req.session.userEmail;
  console.log(`session.userEmail: ${userEmail}`)
  console.log(`post clients/add name: ${name}`);  
  console.log(`post clients/add address: ${address}`);  
  console.log(`post clients/add clientEmail: ${clientEmail}`);  
  console.log(`post clients/add clientPassword: ${clientPassword}`);


  try {
    clientService.addClient(userEmail, name, address, clientEmail, clientPassword);
    res.redirect('/clients')

  } catch (error) {
    console.error('Error logging in @ post.client.add:', error);
    res.status(500).render('addClient', { errorMessage: 'An error occurred. Please try again.' });
  }


});


// Handle client submission (POST)
import { createHash } from 'crypto';  // Import the specific function from the crypto module
import nodemailer from 'nodemailer';

// Function to send the email with the 6-digit verification code
async function sendVerificationEmail(email) {
    // Generate a 6-digit SHA-1 code based on the email + timestamp
    const hash = createHash('sha1').update(email + Date.now().toString()).digest('hex');
    const code = hash.slice(0, 6);  // Take the first 6 characters from the hash as the code

    try {
       // Save the token to the database using userService
       await userService.saveResetToken(email, code);

        // Set up nodemailer transporter with Gmail SMTP and app-specific password
        let transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'rolnikmichal@gmail.com',  // Your Gmail address
                pass: 'bla bla bla',  // App-specific password from Google
            }
        });

        // Compose the email
        let mailOptions = {
            from: 'rolnikmichal@gmail.com',
            to: email,
            subject: 'Your Verification Code',
            text: `Your verification code is: ${code}. It is valid for 5 minutes.`        };

        // Send the email
        await transporter.sendMail(mailOptions);
        console.log(`Verification code sent to ${email}`);

        return {
            success: true,
            message: 'Verification code sent',
            code: code.toString(),  // Return the code for later use
        };

    } catch (error) {
        console.error('Error sending verification email:', error);
        return { success: false, message: 'Error sending verification email' };
    }
}

// Usage example in your route
router.post('/forgotPassword', async (req, res) => {
    const { email } = req.body;
    const result = await sendVerificationEmail(email);

    if (result.success) {
        res.redirect(`/verify-token?email=${email}`);
    } else {
        res.status(500).render('forgotPassword', { errorMessage: 'Failed to send verification email' });
    }
});


// POST route to verify the token
router.post('/verify-token', async (req, res) => {
  const { email, token } = req.body;
  console.log(`post verify token-${email}`);
  try {
      const isValidToken = await userService.verifyResetToken(email, token);  // Verify the token in your database
      if (isValidToken) {
        console.log (`the token is valid`);
    res.redirect(`/change-password?email=${email}`);
  } else {
    console.log (`the token is not!!! valid`);

    return res.status(400).render('verifyToken', { email, errorMessage: 'Invalid token. Please try again.' });
  }

  } catch (error) {
    
    console.log('Error verifying token');

      console.error('Error verifying token:', error);
      res.status(500).render('verifyToken', { email, errorMessage: 'An error occurred. Please try again later.' });
  }
});


// POST route to change the password
router.post('/change-password', async (req, res) => {
  const { email, password } = req.body;
  console.log(`Email received in POST /change-password: ${email}`);
  console.log(`Password received in POST /change-password: ${password}`);


  try {
      // Validate the password here if necessary
      if (!passwordValidator.validatePasswordLength(password)) {
          return res.status(400).render('changePassword', { email, errorMessage: 'Password does not meet the requirements.' });
      }

      // Hash the new password and update it in the database
      await userService.updatePassword(email, password);

      // Automatically log the user in by saving their email in the session
      req.session.userEmail = email;

      // Redirect to the dashboard or homepage after password reset
      res.redirect('/clients');  // Redirect to a secure page, e.g., the dashboard or client list
  } catch (error) {
      console.error('Error updating password:', error);
      res.status(500).render('changePassword', { email, errorMessage: 'you have already used this password before' });
  }
});
// Handle the verification of the current password
router.post('/verify-current-password', async (req, res) => {
  const { currentPassword } = req.body;
  const userEmail = req.session.userEmail;

  try {
    const isAuthenticated = await userService.authenticateUser(userEmail, currentPassword);
    if (isAuthenticated) {
      // Redirect to the change password page if the current password is correct
      res.redirect(`/change-password?email=${userEmail}`);
    } else {
      res.status(401).render('verifyCurrentPassword', { errorMessage: 'Incorrect current password.' });
    }
  } catch (error) {
    console.error('Error verifying current password:', error);
    res.status(500).render('verifyCurrentPassword', { errorMessage: 'An error occurred. Please try again.' });
  }
});

export default router;
