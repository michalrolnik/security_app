import fs from 'fs';

const passwordPolicy = JSON.parse(fs.readFileSync('./Security/password_policy.json', 'utf8'));

export function validatePasswordLength(password) {
    return password.length >= passwordPolicy.password_requirements.password_length;
}

export function validatePasswordComplexity(password) {
    const hasUpperCase = passwordPolicy.password_requirements.uppercase ? /[A-Z]/.test(password) : true;
    const hasLowerCase = passwordPolicy.password_requirements.lowercase ? /[a-z]/.test(password) : true;
    const hasNumbers = passwordPolicy.password_requirements.numbers ? /\d/.test(password) : true;
    const hasSpecialChars = passwordPolicy.password_requirements.special_characters ? /[!@#$%^&*(),.?":{}|<>]/.test(password) : true;

    return hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChars;
}
