import { createPool } from 'mysql2';

// צור חיבור ל-MySQL
const pool = createPool({
  host: 'localhost',
  user: 'root',
  password: '050796mr',
  database: 'my_data',
  multipleStatements: true  // Enable multiple statements
  
});

// יצא את החיבור כדי להשתמש בו בקבצים אחרים
export default pool.promise();