import db from './db/config.js';  // Database connection
import crypto from 'crypto';      // For password hashing


// Get all clients
export async function getClients() {
  try {
    console.log(`getClients()`);

    // Fetch the clients
    const [clients] = await db.query("SELECT name, address, email, password FROM clients");
    
    if (!clients || clients.length === 0) {
      console.log('No clients found');
      return [];
    }

    return clients;  // Return the clients
    
    } catch (error) {
    console.error('Error fetching clients:', error);
    throw new Error('Error fetching clients');
    }
}

// Get clients by user email
export async function getClientsByUserEmail(email) {
  try {
    console.log(`email recived in getclientbyuseremail:${email}`);
    // Fetch the logged-in user's ID using their email
    
    const [userRows] = await db.query("SELECT id FROM users WHERE email = ?", [email]);
    if (!userRows || userRows.length === 0) {
      console.log('User not found for provided email');
      return [];
    }
    
    const userId = userRows[0].id;
    console.log(`userid recived in getclientbyuseremail:${userId}`);

    // Fetch the clients associated with the user's ID
    const [clients] = await db.query("SELECT name, address, email, password FROM clients WHERE user_id = ?", [userId]);
    
    if (!clients || clients.length === 0) {
      console.log('No clients found for this user');
      return [];
    }

    return clients;  // Return the clients for the user
  } catch (error) {
    console.error('Error fetching clients:', error);
    throw new Error('Error fetching clients');
  }
}

// Add a new client associated with the user
export async function addClient(userEmail, name, address, clientEmail, clientPassword) {
  try {
    console.log(`user email recieved in addclient: ${userEmail}`);
    // Fetch the user ID for the current user using their email
    // Safe Version
    // const [userRows] = await db.query("SELECT id FROM users WHERE email = ?", [userEmail]);
    // Hash the client's password before saving it
    //const hashedPassword = crypto.createHash('sha256').update(clientPassword).digest('hex');
  
    //כשרציתי להראות ליוזר את הרשומות שמתאימות ללקוחות שלו , אז בהוספת משתמש חדש הייתי שולחת גם את ה userid:
    //גם זה קוד מאובטח בגלל ה ???
    // Insert the new client into the database, associating them with the user ID
    //const query = 'INSERT INTO clients (user_id, name, address, email, password) VALUES (?, ?, ?, ?, ?)';
    //await db.query(query, [userId, name, address, clientEmail, hashedPassword]);



    // Unsafe Version
    const [userRows] = await db.query(`SELECT id FROM users WHERE email = "${userEmail}";`);
    if (!userRows || userRows.length === 0) {
      throw new Error('User not found');
    }

    const userId = userRows[0].id;  // Get the user's ID from the users table

    // Unsafe query: No parameterization for user-provided inputs
      const query = `
      INSERT INTO clients (user_id, name, address, email, password) 
      VALUES (${userId}, "${name}", "${address}", "${clientEmail}", "${clientPassword}");
    `;
    console.log('Final SQL Query:', query);  // Log the constructed SQL query

    // Execute the query (unsafe)
    await db.query(query);

    console.log('Client added successfully');
  } catch (error) {
    console.error('Error adding client:', error);
    // throw new Error('Error adding client');
  }
}


export default {
  getClients,
  getClientsByUserEmail,
  addClient,
};