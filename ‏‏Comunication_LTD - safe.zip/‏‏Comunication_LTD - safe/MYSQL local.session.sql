CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100)NOT NULL,
    password_ VARCHAR(100) NOT NULL
   
);
INSERT INTO users (username, email,password_) VALUES
('john_doe', 'john@example.com',111),
('jane_smith', 'jane@example.com',222),
('bob_jones', 'bob@example.com',333);

SELECT * FROM users;

CREATE TABLE IF NOT EXISTS settings (
    `key` VARCHAR(255) PRIMARY KEY, -- This will store the 'salt' key
    value TEXT -- This will store the salt value (or any other config values you might add later)
);

SELECT * FROM settings WHERE `key` = 'salt';

SELECT * FROM users WHERE username = 'michal';

SELECT * FROM users WHERE email = 'rolnikmichal@gmail.com';

CREATE TABLE clients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,  -- Foreign key to associate clients with a specific user
  name VARCHAR(255) NOT NULL,
  address VARCHAR(255),
  email VARCHAR(255),
  password VARCHAR(255),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);



SELECT * FROM clients;

INSERT INTO clients (name,address,email,password) VALUES
('bobo', 'gordon 10' ,'bobo@example.com',333),();

ALTER TABLE users ADD COLUMN reset_token VARCHAR(255);

SHOW COLUMNS FROM clients;


select * from users 
delete from clients where name='מיכל רולניק'
select * from clients
UPDATE clients
SET password = '111'
WHERE id = 23;


delete from clients where address='injection'
\
CREATE TABLE password_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    password_hash VARCHAR(64) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

drop TABLE password_history;


update clients SET address="PWN" where id = 25

delete from clients where address='injection'