import crypto from 'crypto';
import db from '../db/config.js'; // MySQL connection

// Function to create Salt and store it in the database if not present
export async function initializeSalt() {
  console.log('Start initializing salt');
  try {
    // Check if Salt already exists in the `settings` table
    const [rows] = await db.query("SELECT value FROM settings WHERE `key` = 'salt'");
    console.log('Salt query result:', rows); // Log the result of the query

    if (rows.length === 0) {
      console.log('No salt found, creating new one');
      // If Salt doesn't exist, create it
      const salt = crypto.randomBytes(16).toString('hex');
      const sha1Salt = crypto.createHash('sha1').update(salt).digest('hex');

      // Save the Salt in the database
      await db.query("INSERT INTO settings (`key`, value) VALUES ('salt', ?)", [sha1Salt]);
      console.log('New salt created and saved:', sha1Salt);
    } else {
      console.log('Salt already exists:', rows[0].value);
    }
  } catch (error) {
    console.error('Error creating/retrieving salt:', error);
  }
}

export default initializeSalt;
