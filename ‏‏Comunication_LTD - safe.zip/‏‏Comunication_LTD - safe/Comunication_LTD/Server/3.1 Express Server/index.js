import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import db from './db/config.js';
import mainRoutes from './mainRoutes.js';
import session from 'express-session';


const app = express();
const port = 3000;

// קבלת הנתיב של הקובץ הנוכחי
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


// Set up session middleware
app.use(session({
  secret: 'your-secret-key',  // Replace this with a strong secret key
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }  // Set to true if using HTTPS
}));

// app.use(helmet.contentSecurityPolicy({
//   directives: {
//       defaultSrc: ["'self'"],
//       scriptSrc: ["'self'"]
//   }
// }));


// הגדרת EJS כתצוגה ברירת מחדל
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../../Client/Views'));

// הגדרת תיקיית Client כסטטית
app.use(express.static(path.join(__dirname, '../../Client')));

// ניתוח נתוני טופס POST
app.use(express.urlencoded({ extended: true }));

app.use('/', mainRoutes);

// מסלול GET לשליחת דף ההרשמה
//app.get('/', (req, res) => {
  //res.render('homepage');
//});

// מסלול POST לרישום משתמש
/* app.post('/register', async (req, res) => {
  const { email, password } = req.body;

  try {
    // שמור את הנתונים למסד הנתונים
    const query = 'INSERT INTO users (email, password) VALUES (?, ?)';
    await db.query(query, [email, password]);

    console.log('User registered successfully.');
    res.send('Registration successful!');
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).send('An error occurred.');
  }
}); */

app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
