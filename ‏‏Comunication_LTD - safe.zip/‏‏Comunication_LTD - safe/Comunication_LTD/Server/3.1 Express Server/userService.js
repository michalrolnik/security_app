import db from './db/config.js';
import crypto from 'crypto';
import * as saltManager from './Security/saltManager.js';


// Register a new user by hashing the password with a global salt
export async function registerUser(username, email, password) {
  try {
    console.log(`US username: ${username}`);
    console.log(`US email: ${email}`);
    console.log(`US password: ${password}`);
    // Check if the email already exists
    
    // Safe version-1comment
    const [existingUser] = await db.query('SELECT id FROM users WHERE email = ?', [email]);
    // Unsafe version-2comments
    //const db_query = `SELECT id FROM users WHERE email = "${email}";`;
    //console.log(`query: ${db_query}`);
    //const [existingUser] = await db.query(db_query); 
    
    if (existingUser.length > 0) {
      throw new Error('Email already exists'); // Email is already in use
    }


    // Initialize or retrieve the global salt
    console.log('Before calling initializeSalt');
    await saltManager.initializeSalt();
    console.log('Salt initialized');

    // Fetch the salt from the database after initialization
    const [saltRows] = await db.query("SELECT value FROM settings WHERE `key` = 'salt'");
    if (!saltRows || saltRows.length === 0) {
      console.log('Salt not found in the database.');
      throw new Error('Salt not found');
    }

    const salt = saltRows[0].value;
    console.log(`Salt retrieved from DB: ${salt}`);

    // Combine the password with the salt and hash it
    const saltedPassword = password + salt;
    console.log(`Salted password: ${saltedPassword}`);
    const hashedPassword = crypto.createHash('sha256').update(saltedPassword).digest('hex');
    console.log(`Hashed password: ${hashedPassword}`);

    // Insert user into the users table
    const query = 'INSERT INTO users (username, email, password_) VALUES (?, ?, ?)';
    await db.query(query, [username, email, hashedPassword]);
    console.log('User registered successfully and data inserted into the database.');
  } catch (error) {
    console.error('Error inserting user into the database:', error);
    throw new Error('Error during user registration.');
  }
}


export async function authenticateUser(email, password) {
  try {
    console.log('Starting user authentication...');  // Logging to trace flow

    // Fetch the global salt from the settings table
    const [saltRows] = await db.query("SELECT value FROM settings WHERE `key` = 'salt'");
    if (!saltRows || saltRows.length === 0) {
      throw new Error('Salt not found in the database');
    }
    const salt = saltRows[0].value;
    console.log(`salt: ${salt}`);

    // Hash the provided password with the salt
    const saltedPassword = password + salt;
    const hashedPassword = crypto.createHash('sha256').update(saltedPassword).digest('hex');
    console.log(`hashed password: ${hashedPassword}`);

    // Fetch the user's stored hashed password along with their ID
    console.log(`Email provided during login: ${email}`);
    // Unafe version
    //const query = `SELECT password_ FROM users WHERE email = "${email}";`;
    //console.log(`[+] ${query}`)
    //const [userRows] = await db.query(`SELECT password_ FROM users WHERE email = "${email}"`);
    // Safe version
    const [userRows] = await db.query("SELECT password_ FROM users WHERE email = ?", [email]);

    // Check if user exists
    if (!userRows || userRows.length === 0) {
      console.log('USsssUser not found in authenticateUser');
      return false;  // User does not exist
    }

    const storedHashedPassword = userRows[0].password_;
    console.log(`stored hashed password: ${storedHashedPassword}`);

    // Compare the provided hashed password with the stored hashed password
    if (hashedPassword === storedHashedPassword) {
      console.log('User authenticated successfully in authenticateUser');
      return true;
    } else {
      console.log('Invalid password in authenticateUser');
      return  false;
    }
  } catch (error) {
    console.error('Error authenticating user:', error);
    throw new Error('Error during user authentication.');
  }
}

// Save the reset token to the database
export async function saveResetToken(email, token) {
  const query = 'UPDATE users SET reset_token = ? WHERE email = ?';
  await db.query(query, [token, email]);
}

// Verify if the reset token matches
export async function verifyResetToken(email, token) {
  console.log(`Email received in userService verifyResetToken: ${email}`);
  const [rows] = await db.query('SELECT reset_token FROM users WHERE email = ?', [email]);

  if (!rows.length) {
    console.log('No user found with this email');
    return false;
  }

  const storedToken = rows[0].reset_token;
  console.log(`Token from database: ${storedToken}`);
  console.log(`Token provided by user: ${token}`);

  return storedToken && storedToken.trim() === token.trim();  // Compare tokens
}


// Update the password for a user
export async function updatePassword(email, newPassword) {
  const [saltRows] = await db.query("SELECT value FROM settings WHERE `key` = 'salt'");
  const salt = saltRows[0].value;
  
  // Hash the new password with the salt
  const saltedPassword = newPassword + salt;
  const hashedPassword = crypto.createHash('sha256').update(saltedPassword).digest('hex');
  
  // Update the password in the database
  const query = 'UPDATE users SET password_ = ?, reset_token = NULL WHERE email = ?';
  await db.query(query, [hashedPassword, email]);
}

//i didnt use it eventualy
export async function findUserByEmail(email) {
  const [rows] = await db.query('SELECT id, email FROM users WHERE email = ?', [email]);
  if (rows.length === 0) {
    console.log('User not found');
    return null;  // No user found with this email
  }
  return rows[0];  // Return the found user
}


export default {
  findUserByEmail,
  registerUser,
  authenticateUser,
  updatePassword,
  verifyResetToken,
  saveResetToken
};